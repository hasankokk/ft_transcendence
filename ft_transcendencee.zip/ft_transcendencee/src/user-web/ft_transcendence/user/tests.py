from django.test import TestCase
#from user.models import Friends

#class FriendsTestCase(TestCase):
#    def setUp(self):
#
