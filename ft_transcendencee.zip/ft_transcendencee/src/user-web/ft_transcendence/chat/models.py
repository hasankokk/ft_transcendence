from django.conf import settings
from django.db import models

class Chat(models.Model):
    name = models.CharField(max_length=50, unique=True)

class ChatRoom(models.Model):
    class Meta:
        verbose_name_plural = "chat rooms"

    chat = models.ForeignKey(Chat, on_delete=models.CASCADE)
    user1 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                              related_name="chat_user1")
    user2 = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
                              related_name="chat_user2")
    user1_score = models.IntegerField()
    user2_score = models.IntegerField()