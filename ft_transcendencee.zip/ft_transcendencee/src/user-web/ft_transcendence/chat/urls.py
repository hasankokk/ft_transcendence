from django.urls import path

from . import views

app_name = "chat"

urlpatterns = [
    path("", views.indexView, name="index"),
    path('users/', views.users, name='users'),
    path('channels/', views.channels, name='channels'),
    path('messages/', views.messages, name='messages'),
]