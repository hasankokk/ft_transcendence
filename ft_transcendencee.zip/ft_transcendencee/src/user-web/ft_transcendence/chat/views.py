from django.shortcuts import render #redirect
#from django.contrib.auth.decorators import login_required

from channels.generic.websocket import AsyncWebsocketConsumer
import json
from rest_framework.decorators import api_view
#from django.contrib.auth.models import User
#from .models import Message, Channel # settings.py'de tanımlanacak
#from django.http import JsonResponse




# YAPIM AŞAMASINDA - FAZLA BAKARSANIZ KÖR OLABİLİRSİNİZ

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self): # Bağlantı burada kabul edilecek
        await self.accept()

    async def disconnect(self, close_code): # Bağlantı burada sonlandırılacak
        pass

    async def receive(self, text_data): # Mesaj alındığında burada işlenecek
        pass


def users(request):
    return render(request, 'chat/users.html')


def channels(request):
    return render(request, 'chat/channels.html')


def messages(request):
    return render(request, 'chat/messages.html')


@api_view(['GET'])
def indexView(request):
	return render(request, 'chat/index.html')

# DRAFT - TO BE CONTINUED
"""
@login_required
def chat(request):
    # kullanıcıları al
    users = User.objects.exclude(username=request.user.username)

    # kanalları al
    channels = Channel.objects.all()

    # mesajları al
    messages = Message.objects.filter(sender=request.user)

    context = {
        'users': users,
        'channels': channels,
        'messages': messages,
    }
    return render(request, 'chat/chat.html', context)

@login_required
def channel_chat(request, channel_id):
    # Kanalı al
    channel = Channel.objects.get(id=channel_id)

    # Kanalın mesajlarını al
    messages = channel.messages.all()

    context = {
        'channel': channel,
        'messages': messages,
    }
    return render(request, 'chat/channel_chat.html', context)

@login_required
def private_chat(request, user_id):
    # Hedef kullanıcıyı al
    target_user = User.objects.get(id=user_id)

    # Kullanıcının gönderdiği ve hedef aldığı mesajları al
    sent_messages = Message.objects.filter(sender=request.user, receiver=target_user)
    received_messages = Message.objects.filter(sender=target_user, receiver=request.user)

    # Tüm mesajları birleştir ve sırala
    messages = (sent_messages | received_messages).order_by('timestamp')

    context = {
        'target_user': target_user,
        'messages': messages,
    }
    return render(request, 'chat/private_chat.html', context)

@login_required
def send_message(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        receiver_id = data['receiver_id']
        message_content = data['message']

        # Alıcıyı al
        receiver = User.objects.get(id=receiver_id)

        # Mesajı kaydet
        message = Message(sender=request.user, receiver=receiver, content=message_content)
        message.save()

        return JsonResponse({'success': True})
    else:
        return JsonResponse({'success': False, 'error': 'Invalid request method'})
"""